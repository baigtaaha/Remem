package com.example.memorypowertest;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import android.media.MediaPlayer;
import android.view.View;



import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    private TextView questionText, commentText;
    private Button option1, option2, option3;

    private MediaPlayer correctSound, wrongSound;


    private int currentQuestion = 0, score = 0;
    private List<String[]> questions = new ArrayList<>();
    private final Random random = new Random();

    private String getFunnyComment(boolean correct) {
        if (correct) {
            String[] funny = {
                    "🎯 Lucky guess or genius?",
                    "🧠 Neurons firing today!",
                    "🔥 Show-off!",
                    "👏 Brain level: 9000!",
                    "😎 Genius alert!"
            };
            return funny[random.nextInt(funny.length)];
        } else {
            String[] funny = {
                    "🤦‍♀️ Memory not found.",
                    "😂 Forgot faster than battery drain.",
                    "🧃 Drink juice and try again.",
                    "🥴 Brain said 'Nope!'",
                    "💤 Did you even try?"
            };
            return funny[random.nextInt(funny.length)];
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        questionText = findViewById(R.id.questionText);
        commentText = findViewById(R.id.commentText);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);



        // ✅ Sounds
        correctSound = MediaPlayer.create(this, R.raw.correct);
        wrongSound   = MediaPlayer.create(this, R.raw.wrong);

        // ✅ All Questions
        questions.add(new String[]{"ACTIVITY, FRAGMENT, INTENT", "Which one is NOT an Android layout component?", "Fragment", "Activity", "LinearLayout", "LinearLayout"});
        questions.add(new String[]{"KOTLIN, JAVA, PYTHON", "Which language is commonly used for Android development?", "Python", "Kotlin", "C++", "Kotlin"});
        questions.add(new String[]{"XML, JAVA, HTML", "Which file type is used for UI design?", "XML", "HTML", "TXT", "XML"});
        questions.add(new String[]{"ANDROID STUDIO, XCODE, VS CODE", "Which IDE is mainly used?", "Android Studio", "Xcode", "IntelliJ IDEA", "Android Studio"});
        questions.add(new String[]{"BUTTON, TEXTVIEW, INTENT", "Which one is used for navigation?", "TextView", "Button", "Intent", "Intent"});
        questions.add(new String[]{"ONCREATE, ONPAUSE, ONSTOP", "First lifecycle method?", "onCreate()", "onPause()", "onStop()", "onCreate()"});
        questions.add(new String[]{"MANIFEST, RES, BUILD", "Which file declares permissions?", "AndroidManifest.xml", "strings.xml", "activity_main.xml", "AndroidManifest.xml"});
        questions.add(new String[]{"TOAST, SNACKBAR, TOY", "Which is NOT used for messages?", "Toast", "Snackbar", "Toy", "Toy"});
        questions.add(new String[]{"IMAGEVIEW, TEXTVIEW, VIDEO", "Which is NOT a View?", "TextView", "Video", "ImageView", "Video"});
        questions.add(new String[]{"INTENT, BUNDLE, PACKAGE", "Used to pass data?", "Bundle", "Intent", "String", "Intent"});

        showMemoryScreen();
    }

    private void showMemoryScreen() {
        if (currentQuestion < questions.size()) {

            String[] q = questions.get(currentQuestion);
            questionText.setText("🧠 Memorize: " + q[0]);
            commentText.setText("");

            option1.setEnabled(false);
            option2.setEnabled(false);
            option3.setEnabled(false);

            option1.setText("");
            option2.setText("");
            option3.setText("");

            new Handler().postDelayed(() -> showRecallScreen(q), 3000);

        } else {
            Intent intent = new Intent(this, ResultActivity.class);
            intent.putExtra("score", score);
            startActivity(intent);
            finish();
        }
    }

    private void showRecallScreen(String[] q) {
        questionText.setText(q[1]);
        commentText.setText("");

        option1.setText(q[2]);
        option2.setText(q[3]);
        option3.setText(q[4]);

        option1.setEnabled(true);
        option2.setEnabled(true);
        option3.setEnabled(true);

        option1.setOnClickListener(v -> checkAnswer(q[2], q[5]));
        option2.setOnClickListener(v -> checkAnswer(q[3], q[5]));
        option3.setOnClickListener(v -> checkAnswer(q[4], q[5]));
    }

    private void checkAnswer(String chosen, String correct) {

        boolean correctAns = chosen.equals(correct);

        // ✅ Sound
        if (correctAns) correctSound.start();
        else wrongSound.start();

        // ✅ Animation


        // ✅ Feedback
        questionText.setText(correctAns ? "✅ Correct!" :
                "❌ Wrong! Correct answer: " + correct);

        if (correctAns) score += 10;

        option1.setEnabled(false);
        option2.setEnabled(false);
        option3.setEnabled(false);

        new Handler().postDelayed(() -> {
            commentText.setText(getFunnyComment(correctAns));
            commentText.setScaleX(0f);
            commentText.setScaleY(0f);
            commentText.animate().scaleX(1f).scaleY(1f).setDuration(400).start();
        }, 900);

        new Handler().postDelayed(() -> {

            currentQuestion++;
            showMemoryScreen();
        }, 2500);
    }

    @Override
    protected void onDestroy() {
        if (correctSound != null) correctSound.release();
        if (wrongSound != null) wrongSound.release();
        super.onDestroy();
    }
}
