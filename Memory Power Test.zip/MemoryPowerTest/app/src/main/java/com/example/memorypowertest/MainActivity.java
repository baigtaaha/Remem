package com.example.memorypowertest;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button startBtn = findViewById(R.id.startQuizBtn);
        Button historyBtn = findViewById(R.id.viewHistoryBtn);

        // ✅ Reusable animated click listener
        View.OnClickListener animatedClick = view -> {

            // ✅ Button shrink animation
            view.animate()
                    .scaleX(0.90f)
                    .scaleY(0.90f)
                    .setDuration(100)
                    .withEndAction(() -> {

                        // ✅ Bounce back animation
                        view.animate()
                                .scaleX(1f)
                                .scaleY(1f)
                                .setDuration(100)
                                .start();

                        // ✅ Actions
                        if (view.getId() == R.id.startQuizBtn) {
                            Toast.makeText(this, "Starting Test 🧠", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, GameActivity.class);
                            startActivity(intent);

                        } else if (view.getId() == R.id.viewHistoryBtn) {
                            Toast.makeText(this, "Opening History 📘", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                            startActivity(intent);
                        }
                    })
                    .start();
        };

        // ✅ Apply animation + action to buttons
        startBtn.setOnClickListener(animatedClick);
        historyBtn.setOnClickListener(animatedClick);
    }
}
