package com.example.memorypowertest;

import android.app.Activity;

public class MainAcAtivity extends Activity {
}
